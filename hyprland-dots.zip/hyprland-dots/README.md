# My Hyprland Setup
![Screenshot](screenshots/preview.png)

## Features
- Hyprland with animations
- Custom Waybar
- Wofi launcher

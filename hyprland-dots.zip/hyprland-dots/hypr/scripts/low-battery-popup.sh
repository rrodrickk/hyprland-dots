#!/bin/bash
rofi -e "⚠️ BATTERY AT 10%! PLUG IN CHARGER!" -theme-str 'window {width: 30%; location: north; anchor: north; y-offset: 10; } listview {lines: 1;} element {text-color: #bf616a;}' -theme ~/.config/rofi/style.rasi
